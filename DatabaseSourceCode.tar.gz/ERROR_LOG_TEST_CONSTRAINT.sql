--------------------------------------------------------
--  Constraints for Table ERROR_LOG_TEST
--------------------------------------------------------

  ALTER TABLE "HARRIAGUE"."ERROR_LOG_TEST" MODIFY ("FILENAME" NOT NULL ENABLE);
 
  ALTER TABLE "HARRIAGUE"."ERROR_LOG_TEST" MODIFY ("ERROR_NRO" NOT NULL ENABLE);
 
  ALTER TABLE "HARRIAGUE"."ERROR_LOG_TEST" MODIFY ("ERROR_MESG" NOT NULL ENABLE);

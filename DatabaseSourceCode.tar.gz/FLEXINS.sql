--------------------------------------------------------
--  DDL for Table FLEXINS
--------------------------------------------------------

  CREATE TABLE "HARRIAGUE"."FLEXINS" OF "HARRIAGUE"."XMLTYPE"
 ;

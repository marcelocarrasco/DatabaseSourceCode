--------------------------------------------------------
--  DDL for Table CTI_XML_3G_NORTE
--------------------------------------------------------

  CREATE TABLE "HARRIAGUE"."CTI_XML_3G_NORTE" OF "HARRIAGUE"."XMLTYPE"
 ;

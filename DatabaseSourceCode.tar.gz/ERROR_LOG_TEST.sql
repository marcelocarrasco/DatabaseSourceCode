--------------------------------------------------------
--  DDL for Table ERROR_LOG_TEST
--------------------------------------------------------

  CREATE TABLE "HARRIAGUE"."ERROR_LOG_TEST" 
   (	"ID" NUMBER(*,0), 
	"FILENAME" VARCHAR2(1000 BYTE), 
	"ERROR_NRO" NUMBER, 
	"ERROR_MESG" VARCHAR2(4000 BYTE)
   ) ;

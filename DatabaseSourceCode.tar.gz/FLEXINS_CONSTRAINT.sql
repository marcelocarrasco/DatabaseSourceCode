--------------------------------------------------------
--  Constraints for Table FLEXINS
--------------------------------------------------------

  ALTER TABLE "HARRIAGUE"."FLEXINS" ADD UNIQUE ("SYS_NC_OID$") ENABLE;

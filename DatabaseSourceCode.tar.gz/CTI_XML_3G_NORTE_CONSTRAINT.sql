--------------------------------------------------------
--  Constraints for Table CTI_XML_3G_NORTE
--------------------------------------------------------

  ALTER TABLE "HARRIAGUE"."CTI_XML_3G_NORTE" ADD UNIQUE ("SYS_NC_OID$") ENABLE;

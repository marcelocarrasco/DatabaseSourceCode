--------------------------------------------------------
--  DDL for Index ERRROR_LOG_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "HARRIAGUE"."ERRROR_LOG_PK" ON "HARRIAGUE"."ERROR_LOG" ("ID") 
  ;

--------------------------------------------------------
--  DDL for Table ALL_C_NSN_EXTERNAL_RC4
--------------------------------------------------------

  CREATE TABLE "HARRIAGUE"."ALL_C_NSN_EXTERNAL_RC4" 
   (	"FILENAME" VARCHAR2(1000 BYTE), 
	"DATE_IMPORT" DATE, 
	"STATUS" VARCHAR2(10 BYTE), 
	"MEASUREMENT_TYPE" VARCHAR2(100 BYTE)
   ) ;

--------------------------------------------------------
--  Constraints for Table ERROR_LOG_NEW
--------------------------------------------------------

  ALTER TABLE "HARRIAGUE"."ERROR_LOG_NEW" MODIFY ("OBJETO" NOT NULL ENABLE);
 
  ALTER TABLE "HARRIAGUE"."ERROR_LOG_NEW" MODIFY ("SQL_CODE" NOT NULL ENABLE);
 
  ALTER TABLE "HARRIAGUE"."ERROR_LOG_NEW" MODIFY ("SQL_ERRM" NOT NULL ENABLE);
